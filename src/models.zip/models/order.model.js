module.exports = {
    "table": "order",
    "columns": [
      {
        "name": "id",
        "type": "varchar(64)",
        "primaryKey": true,
        "notNull": true,
        "description": "订单唯一标识"
      },
      {
        "name": "user_id",
        "type": "varchar(64)",
        "notNull": true,
        "description": "用户ID",
        "relation": {
          "table": "user",
          "field": "id"
        }
      },
      {
        "name": "order_number",
        "type": "varchar(64)",
        "notNull": true,
        "unique": true,
        "description": "订单号"
      },
      {
        "name": "total_amount",
        "type": "decimal(10,2)",
        "notNull": true,
        "description": "总金额"
      },
      {
        "name": "status",
        "type": "varchar(32)",
        "notNull": true,
        "default": "'PENDING'",
        "description": "状态"
      },
      {
        "name": "created_at",
        "type": "timestamptz",
        "notNull": true,
        "default": "now()",
        "description": "创建时间"
      },
      {
        "name": "updated_at",
        "type": "timestamptz",
        "notNull": true,
        "default": "now()",
        "description": "更新时间"
      }
    ]
};