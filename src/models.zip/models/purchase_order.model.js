module.exports = {
    "table": "purchase_order",
    "columns": [
      {
        "name": "id",
        "type": "integer",
        "primaryKey": true,
        "notNull": true,
        "default": "autoincrement()",
        "description": "采购订单唯一标识"
      },
      {
        "name": "order_number",
        "type": "varchar(50)",
        "notNull": true,
        "description": "订单号"
      },
      {
        "name": "supplier_id",
        "type": "integer",
        "notNull": false,
        "description": "供应商ID"
      },
      {
        "name": "employee_id",
        "type": "integer",
        "notNull": false,
        "description": "员工ID"
      },
      {
        "name": "total_amount",
        "type": "decimal(12,2)",
        "notNull": false,
        "description": "总金额"
      },
      {
        "name": "status",
        "type": "varchar(20)",
        "notNull": false,
        "default": "'pending'",
        "description": "状态"
      },
      {
        "name": "remark",
        "type": "text",
        "notNull": false,
        "description": "备注"
      },
      {
        "name": "created_at",
        "type": "timestamp",
        "notNull": false,
        "default": "now()",
        "description": "创建时间"
      },
      {
        "name": "updated_at",
        "type": "timestamp",
        "notNull": false,
        "default": "now()",
        "description": "更新时间"
      }
    ]
};