module.exports = {
    "table": "supplier",
    "columns": [
      {
        "name": "id",
        "type": "integer",
        "primaryKey": true,
        "notNull": true,
        "default": "autoincrement()",
        "description": "供应商唯一标识"
      },
      {
        "name": "name",
        "type": "varchar(100)",
        "notNull": true,
        "description": "供应商名称"
      },
      {
        "name": "contact_person",
        "type": "varchar(50)",
        "notNull": false,
        "description": "联系人"
      },
      {
        "name": "phone",
        "type": "varchar(20)",
        "notNull": false,
        "description": "电话"
      },
      {
        "name": "email",
        "type": "varchar(100)",
        "notNull": false,
        "description": "邮箱"
      },
      {
        "name": "address",
        "type": "text",
        "notNull": false,
        "description": "地址"
      },
      {
        "name": "status",
        "type": "varchar(20)",
        "notNull": false,
        "default": "'active'",
        "description": "状态"
      },
      {
        "name": "created_at",
        "type": "timestamp",
        "notNull": false,
        "default": "now()",
        "description": "创建时间"
      },
      {
        "name": "updated_at",
        "type": "timestamp",
        "notNull": false,
        "default": "now()",
        "description": "更新时间"
      }
    ]
};